<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="TileBien" tilewidth="8" tileheight="8" tilecount="8" columns="8">
 <image source="TileBien.png" trans="000000" width="64" height="8"/>
</tileset>
